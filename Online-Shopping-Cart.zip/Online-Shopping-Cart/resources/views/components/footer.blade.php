<footer>
    <div class="rowfoot1">
        <ul class="colfoot">
            <li><a href="https://www.thegioididong.com/lich-su-mua-hang" title="Lịch sử mua hàng">Lịch sử mua hàng</a></li>
            <li><a href="https://www.thegioididong.com/tra-gop" title="Hướng dẫn mua trả góp">Tìm hiểu về mua trả góp</a></li>
            <li><a href="https://www.thegioididong.com/bao-hanh" title="Tìm trung tâm bảo hành">Chính sách bảo hành</a></li>
            <li><a href="https://www.thegioididong.com/chinh-sach-bao-hanh-san-pham" title="Chính sách đổi trả">Chính sách đổi trả</a></li>

            <li class="showmore"><a href="javascript:ShowMoreFooterSupportLink()" title="Xem thêm">Xem thêm</a></li>
            <li class="hidden"><a href="https://www.thegioididong.com/giao-hang" title="Giao hàng &amp; Thanh toán">Giao hàng &amp; Thanh toán</a></li>
            <li class="hidden"><a href="https://www.thegioididong.com/huong-dan-mua-hang" title="Hướng dẫn mua online">Hướng dẫn mua online</a></li>
            <li class="hidden"><a href="https://www.thegioididong.com/b2b" title="Mua hàng doanh nghiệp">Bán hàng doanh nghiệp</a></li>
            <li class="hidden"><a href="https://www.thegioididong.com/phieu-mua-hang" title="Phiếu mua hàng">Phiếu mua hàng</a></li>
            <li class="hidden"><a href="https://hddt.thegioididong.com/" target="_blank" title="In hóa đơn điện tử" rel="nofollow noopener">In hóa đơn điện tử</a></li>
            <li class="hidden"><a href="https://www.thegioididong.com/tos" title="Quy chế hoạt động">Quy chế hoạt động</a></li>
            <li class="hidden"><a href="https://www.thegioididong.com/noi-quy-cua-hang" title="Nội quy cửa hàng">Nội quy cửa hàng</a></li>
            <li class="hidden"><a href="https://www.thegioididong.com/chat-luong-phuc-vu" title="Chất lượng phục vụ">Chất lượng phục vụ</a></li>
            <li class="hidden"><a href="https://www.thegioididong.com/trao-thuong" title="Thông tin trao thưởng">Thông tin trao thưởng</a></li>
            <li class="hidden"><a href="https://www.thegioididong.com/chinh-sach-khui-hop-apple" title="Chính sách khui hộp sản phẩm Apple">Chính sách khui hộp sản phẩm Apple</a></li>
        </ul>
        <ul class="colfoot">
            <li><a href="http://mwg.vn/" target="_blank" title="Giới thiệu công ty (mwg.vn)" rel="noopener">Giới thiệu công ty <span>(mwg.vn)</span></a></li>
            <li><a href="https://vieclam.thegioididong.com/" target="_blank" title="Tuyển dụng" rel="noopener">Tuyển dụng</a></li>
            <li><a href="https://www.thegioididong.com/lien-he" title="Gửi góp ý, khiếu nại">Gửi góp ý, khiếu nại</a></li>
            <li><a href="https://www.thegioididong.com/he-thong-sieu-thi-the-gioi-di-dong" title="Tìm siêu thị (2.028 shop)">Tìm siêu thị <span>(2.028 shop)</span></a></li>
            <li>
                <a class="viewmb" rel="nofollow" href="https://www.thegioididong.com/?PostmanRuntime=1&amp;viewtype=desktop&amp;sclient=mobile" title="Xem bản mobile">Xem bản mobile</a>
            </li>
        </ul>
        <ul class="colfoot">
            <li>

                <p>Gọi mua hàng <a href="tel:18001060">1800.1060</a> (7:30 - 22:00)</p>
                <p>Gọi khiếu nại &nbsp; <a href="tel:18001062">1800.1062</a> (8:00 - 21:30)</p>
                <p>Gọi bảo hành &nbsp; <a href="tel:18001064">1800.1064</a> (8:00 - 21:00)</p>
                <p>Kỹ thuật &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <a href="tel:18001763">1800.1763</a> (7:30 - 22:00)</p>
                <a target="_blank" rel="nofollow noopener" class="bct" href="http://online.gov.vn/HomePage/CustomWebsiteDisplay.aspx?DocId=20098" aria-label="bộ công thương mwg"><i class="icontgdd-bct"></i></a>
                <a rel="nofollow noopener" class="bct" href="https://www.thegioididong.com/tos#giai-quyet-khieu-nai" aria-label="bộ công thương chống hàng giả"><i class="icontgdd-hg"></i></a>
                <a href="https://www.dmca.com/Protection/Status.aspx?ID=5b62e759-2a0c-4d86-b972-af903bfbc89d&amp;refurl=http://www.thegioididong.com/?PostmanRuntime=1&amp;viewtype=desktop" title="DMCA.com Protection Status" class="dmca-badge"> <img style="opacity:0.6;margin: 0px auto -8px;display: block;" src="./Thegioididong.com - Điện thoại, Laptop, Phụ kiện, Đồng hồ chính hãng_files/dmca-badge-w100-5x1-11.png" alt="DMCA.com Protection Status"></a>
            </li>
        </ul>
        <ul class="colfoot collast">
            <li>
                <a target="_blank" href="https://facebook.com/thegioididongcom" class="linkfb" rel="noopener">
                    <i class="icontgdd-share1"></i>3.5tr
                </a>
                <a target="_blank" href="https://www.youtube.com/user/TGDDVideoReviews?sub_confirmation=1" class="linkyt" rel="noopener">
                    <i class="icontgdd-share3"></i>728k
                </a>
                <div class="group">
                    <label>Website cùng tập đoàn:</label>
                    <a href="https://www.maiamtgdd.vn/" target="_blank" rel="noopener" class="ma" aria-label="www.maiamtgdd.vn"><i class="iconlogo-ma"></i></a>
                    <a href="https://www.dienmayxanh.com/" target="_blank" rel="noopener" class="dm" aria-label="www.dienmayxanh.com"><i class="iconlogo-dmx"></i></a>
                    <a href="https://www.bachhoaxanh.com/" target="_blank" rel="noopener" class="bhx" aria-label="www.bachhoaxanh.com"><i class="iconlogo-bhx"></i></a>
                </div>
            </li>
        </ul>
    </div>
    <div class="rowfoot2">
        <p>© 2018. Công ty cổ phần Thế Giới Di Động. GPMXH: 238/GP-BTTTT do Bộ Thông Tin và Truyền Thông cấp ngày 04/06/2020. Địa chỉ: 128 Trần Quang Khải, P. Tân Định, Q.1, TP.Hồ Chí Minh. Điện thoại: 028 38125960. Email: cskh@thegioididong.com. Chịu trách nhiệm nội dung: Huỳnh Văn Tốt. <a href="https://www.thegioididong.com/thoa-thuan-su-dung-trang-mxh">Xem chính sách sử dụng</a></p>
    </div>
</footer>
